#include <stdio.h>

int main()
{
  int num1, num2;
  printf("Enter two numbers\n");
  scanf("%d %d", &num1, &num2);
  printf("Result: %d\n", num1 + num2);
  return 0;
}
